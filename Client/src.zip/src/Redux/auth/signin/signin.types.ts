export const SIGN_IN_LOADING = "auth/signin/loading";
export const SIGN_IN_SUCCESS = "auth/signin/success";
export const SIGN_IN_ERROR = "auth/signin/error";
export const SIGN_OUT = "auth/signout";

// Reset
export const RESET_AUTH = "auth/reset";