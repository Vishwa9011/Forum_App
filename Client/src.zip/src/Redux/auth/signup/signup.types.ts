export const SIGN_UP_LOADING = "auth/signup/loading";
export const SIGN_UP_SUCCESS = "auth/signup/success";
export const SIGN_UP_ERROR = "auth/signup/error";
